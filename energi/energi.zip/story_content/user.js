function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5l00qCIEDwn":
        Script1();
        break;
      case "6E6b327u3vo":
        Script2();
        break;
      case "5oYWwYfyMKi":
        Script3();
        break;
      case "61GdMSzL9M1":
        Script4();
        break;
      case "6Or4wLXiNLt":
        Script5();
        break;
      case "5cS5jNxyoTP":
        Script6();
        break;
      case "6NYw5KYieyE":
        Script7();
        break;
      case "5w2CK7uMiTd":
        Script8();
        break;
      case "5sEyElAMKpw":
        Script9();
        break;
      case "6i2tt8VjWLp":
        Script10();
        break;
      case "6nafpo89B26":
        Script11();
        break;
      case "5fIi4MB5A5E":
        Script12();
        break;
      case "6C0BaCEq8gL":
        Script13();
        break;
      case "6JNDhuNSUDm":
        Script14();
        break;
      case "69ueT87wcDs":
        Script15();
        break;
      case "5zw2caJ1MbA":
        Script16();
        break;
      case "68u9VkfWm29":
        Script17();
        break;
      case "5e8toHoufFh":
        Script18();
        break;
      case "6jEBJxxRgEE":
        Script19();
        break;
      case "6hNUVqpklsp":
        Script20();
        break;
      case "5hV8VZsoKDD":
        Script21();
        break;
      case "6P9TUd7cEpy":
        Script22();
        break;
      case "5iBrZTWzmb7":
        Script23();
        break;
      case "5zLrtmTeQ6A":
        Script24();
        break;
      case "5lx4FDPX8TA":
        Script25();
        break;
      case "5fcQrVCYRoV":
        Script26();
        break;
      case "6Tt6atEHQ3i":
        Script27();
        break;
      case "67f8oecqpSZ":
        Script28();
        break;
      case "6A8qlytzua0":
        Script29();
        break;
      case "6CToszU8cJy":
        Script30();
        break;
      case "5ZcD4x12nOl":
        Script31();
        break;
      case "63aerOzIVyN":
        Script32();
        break;
      case "62h7WJg9Qyw":
        Script33();
        break;
      case "6Tw0BLbmy7X":
        Script34();
        break;
      case "6cMrlxTK1k6":
        Script35();
        break;
      case "5qvUCGIb4NE":
        Script36();
        break;
      case "6XjFuqQJ73I":
        Script37();
        break;
      case "692vs2Rb07k":
        Script38();
        break;
      case "6dE6i6sm7OL":
        Script39();
        break;
      case "659gMINiERj":
        Script40();
        break;
      case "5jatbQPShyk":
        Script41();
        break;
      case "6PYTkdUWLvN":
        Script42();
        break;
      case "6lEIBunPL88":
        Script43();
        break;
      case "6AesYqDx364":
        Script44();
        break;
      case "6lt7KPfGyF3":
        Script45();
        break;
      case "5WIFkCsUT1A":
        Script46();
        break;
      case "6e9CLFOYnKe":
        Script47();
        break;
      case "6dkwuXNxqck":
        Script48();
        break;
      case "6VUzhN4u9hO":
        Script49();
        break;
      case "6TmHjT7zSEX":
        Script50();
        break;
      case "6jDIasCIcw9":
        Script51();
        break;
      case "5mcEpPbYpWi":
        Script52();
        break;
      case "6pToKvWnljz":
        Script53();
        break;
      case "5cQhGqFfUOT":
        Script54();
        break;
      case "5hxtFyTndeB":
        Script55();
        break;
      case "5j0AibZ1GMg":
        Script56();
        break;
      case "5bcKJy5ckex":
        Script57();
        break;
      case "6RBc3HUtA87":
        Script58();
        break;
      case "6lQ71txhLbf":
        Script59();
        break;
      case "5ml2gBawKcV":
        Script60();
        break;
      case "5hJYBijPan8":
        Script61();
        break;
      case "6JkxxJB1yzb":
        Script62();
        break;
      case "5j56BRniiNT":
        Script63();
        break;
      case "6N7wdvUt0lk":
        Script64();
        break;
      case "5oReRYHOLL7":
        Script65();
        break;
      case "62dlSIh6mXN":
        Script66();
        break;
      case "6YucDW1xjP5":
        Script67();
        break;
      case "60vdPGLyOKz":
        Script68();
        break;
      case "6gui2TEgEJ8":
        Script69();
        break;
      case "68YOyTzDwVS":
        Script70();
        break;
      case "6LN2NHitkUF":
        Script71();
        break;
      case "6Vpv1UV7efI":
        Script72();
        break;
      case "6at6RRG3KrB":
        Script73();
        break;
  }
}

function Script1()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script2()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script3()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script4()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script5()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script6()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script7()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script8()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script9()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script10()
{
  var audio = document.getElementById('bgSong');
audio.src="musik.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script11()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script12()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script13()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script14()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script15()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script16()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script17()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script18()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script19()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script20()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script21()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script22()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script23()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script24()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script25()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script26()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script27()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script28()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script29()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script30()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script31()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script32()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script33()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script34()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script35()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script36()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script37()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script38()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script39()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script40()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script41()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script42()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script43()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script44()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script45()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script46()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script47()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script48()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script49()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script50()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script51()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script52()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script53()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script54()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script55()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script56()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script57()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script58()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script59()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script60()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script61()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script62()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script63()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script64()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script65()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

function Script66()
{
  var audio = document.getElementById('bgSong');
audio.src="music.mp3";
audio.load();
audio.play();
audio.volume = 1.0;
}

function Script67()
{
  var audio = document.getElementById('bgSong');
audio.src="";
audio.load();
audio.stop();
}

function Script68()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.0;
}

function Script69()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.2;
}

function Script70()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.4;
}

function Script71()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.6;
}

function Script72()
{
  var audio = document.getElementById('bgSong');
audio.volume = 0.8;
}

function Script73()
{
  var audio = document.getElementById('bgSong');
audio.volume = 1.0;
}

